import { combineReducers } from "redux";

import weatherStation from "./weatherStation";

export default combineReducers({ weatherStation });
